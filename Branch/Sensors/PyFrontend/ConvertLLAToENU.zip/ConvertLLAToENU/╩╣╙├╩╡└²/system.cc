#include <eigen3/Eigen/Dense>
#include "util.h"
#include "LocalCartesian.hpp"

        Eigen::Vector3d origin_lla =  Eigen::Vector3d(origin_latitude,origin_longitude,origin_altitude);
        Eigen::Vector3d position_lla =  Eigen::Vector3d(msg_fix.latitude,msg_fix.longitude,msg_fix.altitude);   //纬度，经度，高度
        Eigen::Vector3d position_enu;
        ConvertLLAToENU(origin_lla, position_lla, &position_enu);

           float32 positionx = position_enu[0];
           float32 positiony = position_enu[1];
           float32 positionz = position_enu[2];
           ICV_LOG_INFO << "  longitude  positionx:" << positionx;